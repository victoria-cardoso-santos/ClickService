<template>
    <div>
      <p>olá</p>
    </div>
  </template>
  
  <script>
  
  export default {
    name: 'HomePage',
    data() {
      return {
        
      }
    },
  
    methods: {
     
    }
  }
  </script>
  
  